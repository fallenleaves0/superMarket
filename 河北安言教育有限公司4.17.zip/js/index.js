$(document).ready(function () {
    $("section .about .wrap .about-cont .about-left .lef-img .box").css("width", $(".about-cont .about-left .lef-img ").width() * 2 + "px");
    var $i = 0;
    var $wid = $(".img").width();
    function test(){
        if(parseInt($(".box").css("left"))<0){
            $(".box").append($(".box .img").eq(0));
            $(".box").css("left","0px");
        }else{
            $(".box").stop().animate({ left: -$wid }, 400)
        }
    }
    var j = setInterval(test, 2000);
    $(window).resize(function () {
        $(".about-cont .about-left .lef-img .box").css("width", $(".about-cont .about-left .lef-img ").width() * 2 + "px");
        console.log($(window).width())
        if($(window).width()<974){
            clearInterval(w);
            $wid = $(".img").width();
            var w = setInterval(test, 2000);
        }
        if($(window).width()>974){
            $wid = $(".img").width();
            var w = setInterval(test, 2000);
        }
    });
})