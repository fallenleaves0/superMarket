$(document).ready(function(){
    $.ajax({
        url:"http://127.0.0.1:5500/js/news.json",
        datatype:"get",
        success:function(res){
            console.log(res.data);
            $.each(res.data, function (index, value) {
                console.log(res.data[index].href)
                $(".news-ul").append(                        
                "<li><a href='" +res.data[index].href +"'><div class='news-img' style='background: url("+res.data[index].img +") no-repeat center center;background-size:cover; '></div><div class='news_p'>"+res.data[index].title +"</div><div class='news_txt'>"+res.data[index].txt + "</div></a></li>")
            })
        }
    })
    
})