$(document).ready(function () {
    //二级导航
    $("header nav .nav-md > li").hover(function () {
        $(this).children("ul").stop().slideToggle(500);
    })
    //轮播图左右点击按钮
    $("header #slidershow > a ").mousedown(function () {
        $(this).css("opacity", "1")
    });
    $("header #slidershow > a ").mouseup(function () {
        $(this).css("opacity", "0.5")
    });
    //pc端导航
    $("header .header .wrap .logo span ").click(function () {
        if ($(this).next(".sjdnav").css('height') == '0px') {
            $(this).next(".sjdnav").animate({ "height": "336px" })
        } else if ($(this).next(".sjdnav").css('height') == '336px') {
            $(this).next(".sjdnav").animate({ "height": "0px" })
        }
    })
    //回顶部
    $('.block ul li i.up').click(function () { 
        $('html,body').animate({ scrollTop: '0px' }); 
        return false; 
    });
    //回底部（网页最末端）
    $('.block ul li i.down').click(function () { 
        $('html,body').animate({ scrollTop: document.getElementsByTagName('BODY')[0].scrollHeight });
        return false;
    });
    $(".switch ").click(function(){
        if($(this).prev(".icons").css("right")=="0px"){
            $(this).prev(".icons").animate({"right":"-60px"})
        }else{
            $(this).prev(".icons").animate({"right":"0px"})
        }
    })
})














