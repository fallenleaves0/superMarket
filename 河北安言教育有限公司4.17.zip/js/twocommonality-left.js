$(document).ready(function(){
    $(".about_ul li").click(function(){
        $(this).next(".xxzx").slideToggle()
    })
})