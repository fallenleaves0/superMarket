$(document).ready(function () {
    $(".toubu #DH span").click(function () {
        if ($(".nr").css("height") == "0px") {
            $(".nr").animate({ "height": '700px' }, 1000);
        } else if ($(".nr").css("height") == "700px") {
            $(".nr").animate({ "height": '+0px' }, 1000);
        }
    })
    $(window).scroll(function(){
        if ($(window).scrollTop() >= 50) {
            $("header").addClass("acctive");
            $(".head").addClass("yc");
            $(".showw").addClass("cx");
            
        }else{
            $("header").removeClass("acctive");
            $(".head").removeClass("yc");
            $(".showw").removeClass("cx");
        }
    })
    $(window).scroll(function(){
        if ($(window).scrollTop() >= 200)  {
                 $(".a #nr .x p").fadeIn("slow");
        }else{
            $(".a #nr .x p").fadeOut("slow");
        }
    })


    $(".head #DH .two").hover(function(){
        $(".head #DH .two .ej").stop().slideToggle(0);
    })
    $(".head #DH .three").hover(function(){
        $(".head #DH .three .ej").stop().slideToggle(0);
    })
    $(".head #DH .four").hover(function(){
        $(".head #DH .four .ej").stop().slideToggle(0);
    })


    $(".showw #DH .two").hover(function(){
        $(".showw #DH .two .ej").stop().slideToggle(0);
    })
    $(".showw #DH .three").hover(function(){
        $(".showw #DH .three .ej").stop().slideToggle(0);
    })
    $(".showw #DH .four").hover(function(){
        $(".showw #DH .four .ej").stop().slideToggle(0);
    })

   
})
